/*\
module-type: library

This handles the fetching and distribution of relink settings.

\*/

var utils = require('./utils');

///// Legacy. You used to be able to access the type from utils.
exports.getType = utils.getType;
/////
